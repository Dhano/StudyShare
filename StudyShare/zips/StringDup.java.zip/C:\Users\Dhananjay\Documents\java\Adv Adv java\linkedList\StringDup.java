import java.util.*;

public class StringDup{
	public static void main(String args[]){
		Scanner scanner =new Scanner(System.in);
		String sententce;
		System.out.println("Enter any Sentence");
		sententce=scanner.nextLine();
		String arr[]=new String[10];
		String [] words=sententce.split(" ");
		String [] uniqiueWords=Arrays.stream(words).distinct().toArray(String[]::new);

		for(String s:uniqiueWords){
			System.out.println(s+" ");
		}
	}
}