package com.myjdbc;
import java.sql.*;
public class TestDB{

	public static void main(String args[]){
		try{
			DriverManager.getConnection("jdbc:sqlite:C://USERS//DHANANJAY//Documents//Test.db");
			System.out.println("Yooooo");
		}catch(SQLException e){
			System.out.println("Something went wrong");
		}
	}

}