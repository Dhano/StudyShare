import java.util.*;
class LinkListDemo{
	public static void main(String args[]){
		LinkedList<String> stringList=new LinkedList<>();
		String s1="Red";
		String s2="Blue";
		String s3="Green";
		String s4="Yellow";
		String s5="White";
		String s6="Black";
		stringList.add(s1);
		stringList.add(s2);
		stringList.add(s3);
		stringList.add(s4);
		stringList.add(s5);
		stringList.add(s6);
		printList(stringList);
	}

	void printList(LinkedList<String> list){
		ListIterator iterator =list.listIterator();
		while(iterator.hasNext()){
			System.out.println(list.next());	
		}
	}
}