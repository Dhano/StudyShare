package com;
import java.awt.*;
public class Output
{
	public String show(String s){
		System.out.println("Hey here is some message");
		return new String("HEy can you get me");
	}
}  
