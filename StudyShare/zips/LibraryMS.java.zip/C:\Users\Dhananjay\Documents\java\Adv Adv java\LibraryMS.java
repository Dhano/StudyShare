import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
/*<applet code="LibraryMS" width = "1000" height = "500"></applet>*/

class SampleDialog extends JDialog implements ActionListener{
   SampleDialog(Frame parent,String title,boolean result){
     super(parent,title,true);
	 JLabel resultLabel=new JLabel();
     setLayout(new FlowLayout());
     setSize(200,200);
     if(result==true)
		 resultLabel.setText("Book Issued");
	 else
		 resultLabel.setText("Sorry Book not found");
	 add(resultLabel);
     Button b = new Button("Ok");
     add(b);
     b.addActionListener(this);
	 setVisible(true);
   }

   public void actionPerformed(ActionEvent ae){
     dispose();
   }
}

public class LibraryMS extends JFrame implements ActionListener,ListSelectionListener{
	JList<String> l1;
	//String[] data;
	String msg="",idx;
  	JPanel cards;
  	CardLayout cardLo;
  	JButton searchBook,displayBook,back;
  	JTextField t;
	/*public void init(){
		initializeAll();
	}*/
	LibraryMS(){
     	this.setSize(500,400);
     	// SampleDialog dnew = new SampleDialog(this,"New Dialog");
     	// dnew.setVisible(true);
     	addWindowListener(new WindowAdapter(){
       		public void windowClosing(WindowEvent we){
        		System.exit(0);
       		}
     	});
     	initializeAll();
		this.setVisible(true);
	}

	public void initializeAll(){

		t = new JTextField(20);
		searchBook = new JButton("Search & get");
	    displayBook = new JButton("Display Available Books");
	    back = new JButton("Back");
		 JPanel homePan =new JPanel();
		homePan.add(searchBook);
    	homePan.add(displayBook);
    	homePan.add(t);

		String data[] = {"Advance Java","Advance MUP","System Programming","Data Structures",
	    				"Computer Security","Artificial Intelligence","Object Oriented Modelling & Design"};
		l1 = new JList<String>(data);
		JPanel dispPan = new JPanel();
		dispPan.add(l1);
    	dispPan.add(back);

	    cardLo = new CardLayout();
	    cards = new JPanel();
	    cards.setLayout(cardLo);
	    
	    
    	cards.add(homePan);
    	cards.add(dispPan);
	    
  		//array = new String[8];
    	
    	add(cards); //add cards to main applet Panel.
    	l1.addListSelectionListener(this);
    	searchBook.addActionListener(this);
    	displayBook.addActionListener(this);
    	back.addActionListener(this);
	}

	public void valueChanged(ListSelectionEvent ie){
  		//repaint();
  	}

  	public void actionPerformed(ActionEvent ae){
    	if(ae.getActionCommand() == "Search & get"){
    		System.out.println("Hello");
			ListModel<String> model =l1.getModel();
			for(int i = 0; i < model.getSize(); i++) {
			if(t.getText().equals((String)model.getElementAt(i))){

				new SampleDialog(new Frame(),"Sucess",true);	
			return ;
			}
		 }
		 new SampleDialog(new Frame(),"Failed",false);
		 return ;
		 
    	}else if(ae.getActionCommand() == "Display Available Books"){
    		cardLo.next(cards);
    	}else if(ae.getActionCommand() == "Back"){
    		cardLo.previous(cards);
    	}
   }

   public static void main(String args[]){
   		new LibraryMS();
   }
}