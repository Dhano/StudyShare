import java.lang.reflect.Field;
class Tp{
	private static int h=9;
	public static void main(String args[]){
		for(Field field:Tp.class.getFields())
			System.out.println(field.toString());
	}
	
}
