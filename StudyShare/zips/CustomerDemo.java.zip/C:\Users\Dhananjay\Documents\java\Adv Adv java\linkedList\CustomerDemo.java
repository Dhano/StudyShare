import java.util.ArrayList;
import linkedList;

public class CustomerDemo{
	public static void main(String arsg[]){
		Customer customer= new Customer("Dhano" , 2222.22);
		Customer anotherCustomer=customer;// anothercustomer is referring customer just like strings va
		//value of one change will lead to change in both the objects
		//Copy Constructor ::::::::::: Customer anothercustomer=new Customer(customer);
		anotherCustomer.setBalance(10000.44555);

		ArrayList<Integer> intList=new ArrayList<>();
		intList.add(1);
		intList.add(11);
		intList.add(111);

		for(int i=0;i<intList.size();i++)
		System.out.println(i + " :" + intList.get(i));
	}
}